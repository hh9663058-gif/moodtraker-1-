import React, { useState } from 'react';
import { DiaryIcon } from '../components/icons';

interface LoginPageProps {
  onLogin: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [isLoginView, setIsLoginView] = useState(true);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // This is a mock login, so we just call the onLogin callback
    onLogin();
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-900 p-4">
      <div className="max-w-md w-full mx-auto">
        <div className="text-center mb-8">
            <DiaryIcon className="w-16 h-16 mx-auto text-primary" />
            <h1 className="text-4xl font-bold text-primary mt-2">MoodTracker</h1>
            <p className="text-slate-600 dark:text-slate-300 mt-1">Your personal space for mental wellness.</p>
        </div>
        
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg p-8">
            <div className="flex border-b border-slate-200 dark:border-slate-700">
                <button onClick={() => setIsLoginView(true)} className={`w-1/2 py-3 font-semibold ${isLoginView ? 'text-primary border-b-2 border-primary' : 'text-slate-500'}`}>Login</button>
                <button onClick={() => setIsLoginView(false)} className={`w-1/2 py-3 font-semibold ${!isLoginView ? 'text-primary border-b-2 border-primary' : 'text-slate-500'}`}>Sign Up</button>
            </div>
            
            <form onSubmit={handleSubmit} className="mt-6 space-y-6">
                <input
                    type="email"
                    placeholder="Email Address"
                    required
                    className="w-full px-4 py-3 border border-slate-300 dark:border-slate-600 rounded-lg bg-slate-50 dark:bg-slate-700 focus:ring-2 focus:ring-primary"
                />
                <input
                    type="password"
                    placeholder="Password"
                    required
                    className="w-full px-4 py-3 border border-slate-300 dark:border-slate-600 rounded-lg bg-slate-50 dark:bg-slate-700 focus:ring-2 focus:ring-primary"
                />
                {!isLoginView && (
                     <input
                        type="password"
                        placeholder="Confirm Password"
                        required
                        className="w-full px-4 py-3 border border-slate-300 dark:border-slate-600 rounded-lg bg-slate-50 dark:bg-slate-700 focus:ring-2 focus:ring-primary"
                    />
                )}
                 <button type="submit" className="w-full px-6 py-3 bg-primary text-white font-semibold rounded-lg shadow-md hover:bg-primary-dark transition">
                    {isLoginView ? 'Login' : 'Create Account'}
                </button>
            </form>

            <div className="mt-6 relative">
                <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-slate-300 dark:border-slate-600"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                    <span className="px-2 bg-white dark:bg-slate-800 text-slate-500">Or continue with</span>
                </div>
            </div>

            <div className="mt-6 grid grid-cols-2 gap-3">
                <button onClick={onLogin} className="w-full inline-flex justify-center py-3 px-4 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm bg-white dark:bg-slate-700 text-sm font-medium text-slate-500 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-600">
                    Google
                </button>
                <button onClick={onLogin} className="w-full inline-flex justify-center py-3 px-4 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm bg-white dark:bg-slate-700 text-sm font-medium text-slate-500 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-600">
                   Facebook
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
