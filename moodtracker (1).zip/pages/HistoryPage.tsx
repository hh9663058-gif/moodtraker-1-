import React, { useState, useEffect } from 'react';
import { MoodEntry, MOOD_EMOJI, MOOD_COLORS, MOODS, Mood, MOOD_HEX_COLORS } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const HistoryPage: React.FC = () => {
  const [entries, setEntries] = useState<MoodEntry[]>([]);
  const [chartData, setChartData] = useState<any[]>([]);

  useEffect(() => {
    try {
      const storedEntries = JSON.parse(localStorage.getItem('mood-tracker-entries') || '[]');
      setEntries(storedEntries.sort((a: MoodEntry, b: MoodEntry) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    } catch(error) {
      console.error("Failed to load entries from local storage", error);
      setEntries([]);
    }
  }, []);

  useEffect(() => {
    if (entries.length > 0) {
      const data = entries.reduce((acc, entry) => {
        const date = new Date(entry.date).toLocaleDateString('en-CA'); // YYYY-MM-DD
        if (!acc[date]) {
          acc[date] = { date, ...MOODS.reduce((moodAcc, mood) => ({ ...moodAcc, [mood]: 0 }), {}) };
        }
        acc[date][entry.mood]++;
        return acc;
      }, {} as Record<string, any>);

      // Fix: Explicitly type `a` and `b` to resolve 'unknown' type error in sort.
      const sortedData = Object.values(data).sort((a: { date: string }, b: { date: string }) => new Date(a.date).getTime() - new Date(b.date).getTime()).slice(-30); // Last 30 days
      setChartData(sortedData);
    }
  }, [entries]);

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-lg">
        <h2 className="text-2xl font-bold mb-4 text-slate-800 dark:text-slate-100">Your Mood Trends</h2>
        {entries.length > 0 ? (
          <div style={{ width: '100%', height: 400 }}>
            <ResponsiveContainer>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.2} />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(30, 41, 59, 0.9)', 
                    borderColor: '#334155',
                    borderRadius: '0.5rem',
                  }} 
                  labelStyle={{ color: '#f1f5f9' }}
                />
                <Legend />
                {MOODS.map(mood => (
                  <Bar key={mood} dataKey={mood} stackId="a" fill={MOOD_HEX_COLORS[mood]} />
                ))}
              </BarChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <p className="text-center text-slate-500 dark:text-slate-400">Not enough data to display trends. Keep logging your mood!</p>
        )}
      </div>

      <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-lg">
        <h3 className="text-xl font-bold mb-4 text-slate-800 dark:text-slate-100">Full History</h3>
        <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2">
          {entries.length > 0 ? entries.map(entry => (
            <div key={entry.id} className="p-4 bg-slate-50 dark:bg-slate-700/50 rounded-lg border-l-4" style={{ borderColor: MOOD_HEX_COLORS[entry.mood] }}>
              <div className="flex justify-between items-start">
                <div>
                  <div className="flex items-center space-x-3">
                    <span className="text-2xl">{MOOD_EMOJI[entry.mood]}</span>
                    <span className={`font-semibold ${MOOD_COLORS[entry.mood]}`}>{entry.mood}</span>
                  </div>
                  <p className="mt-2 text-slate-600 dark:text-slate-300">{entry.text}</p>
                </div>
                <span className="text-sm text-slate-500 dark:text-slate-400 flex-shrink-0 ml-4">{new Date(entry.date).toLocaleString()}</span>
              </div>
            </div>
          )) : <p className="text-slate-500 dark:text-slate-400">No entries yet.</p>}
        </div>
      </div>
    </div>
  );
};

export default HistoryPage;
